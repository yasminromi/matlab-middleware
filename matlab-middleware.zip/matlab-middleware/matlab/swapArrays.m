function [X2,Y2,Z2,X1,Y1,Z1] = swapArrays(X1,Y1,Z1,X2,Y2,Z2)

end

